const blockStyle =
  "bg-white rounded-lg shadow-md shadow-gray-300 flex flex-col gap-6 p-6 md:px-8 md:py-6";

export default blockStyle;
