const Subscription = () => {
  return (
    <div className="bg-white rounded-xl p-4">
      <p className="text-dark text-2xl font-bold">No Subscription Yet</p>
    </div>
  );
};

export default Subscription;
