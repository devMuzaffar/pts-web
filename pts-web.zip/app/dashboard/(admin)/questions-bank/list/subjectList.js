const subjectList = [
    "English",
    "Physics",
    "Chemistry",
    "Mathematics",
];

export default subjectList;