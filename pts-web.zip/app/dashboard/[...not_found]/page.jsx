import { notFound } from "next/navigation";

const NotFoundCatchAll = () => {
  notFound();
};

export default NotFoundCatchAll;
