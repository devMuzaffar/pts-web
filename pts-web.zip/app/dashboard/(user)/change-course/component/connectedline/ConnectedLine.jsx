const ConnectedLine = () => {
  return (
    <div className="border-[1px] border-dotted border-secondary w-full"/>
  )
}

export default ConnectedLine