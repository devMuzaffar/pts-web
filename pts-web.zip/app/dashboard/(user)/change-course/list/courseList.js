const courseList = [
    {
        icon: "/dashboard/change-course/1.png",
        title: "ECAT",
        desc: "Engineering College Admission Test"
    },
    {
        icon: "/dashboard/change-course/2.png",
        title: "MDCAT",
        desc: "Medical and Dental College Admission Test"
    },
    {
        icon: "/dashboard/change-course/3.png",
        title: "BCAT",
        desc: "Business College Admission Test"
    },
    {
        icon: "/dashboard/change-course/4.png",
        title: "MATRIC",
        desc: ""
    },
    {
        icon: "/dashboard/change-course/5.png",
        title: "INTERMEDIATE",
        desc: ""
    },
    {
        icon: "/dashboard/change-course/6.png",
        title: "INTERNATIONAL TESTS",
        desc: "International Tests"
    },
]

export default courseList;