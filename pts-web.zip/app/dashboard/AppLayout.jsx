"use client";
import { useState } from "react";
import Loading from "./loading";
import useDelay from "./utils/helpers/useDelay";
import MainComponent from "./components/layout/MainComponent";
import store from "../redux/store";
import useAutoLogin from "../hooks/useAutoLogin";

const AppLayout = ({ children }) => {
  // const [isFirstTime, setIsFirstTime] = useState(true);
  const loading = useAutoLogin();

  // Loading Timer
  // useDelay(() => setIsFirstTime(false), 250);

  return (
      <div className="app flex justify-end relative bg-contentbg overflow-x-hidden">
        {loading ? (
          <Loading isMain={true} />
        ) : (
          <MainComponent>{children}</MainComponent>
        )}
      </div>
  );
};

export default AppLayout;
