export const buttonBaseSx = {
  padding: "6px 18px",
  borderRadius: "18px",
};
