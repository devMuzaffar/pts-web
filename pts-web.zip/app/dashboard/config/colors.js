// These are the colors that changes the whole app
export const primary = "#02A6E5";
export const secondary = "#F29F05";
export const secondaryShade = "#0E4B8D";