// These are the Video Links(By ID) to be used in Home Block-4

const YTLinksID = ["zo5Z_BQTxoM", "FppXoImo-N4", "cQENdfxk3xo"];

export default YTLinksID;