const bottomLinks = [
  {
    icon: "./dashboard/home/bottom/1.png",
    text: "Notes",
  },
  {
    icon: "./dashboard/home/bottom/2.png",
    text: "Apply for Live Classes",
  },
  {
    icon: "./dashboard/home/bottom/3.png",
    text: "Recorded Lectures",
  },
  {
    icon: "./dashboard/home/bottom/4.png",
    text: "Apply for Scholarship",
  },
];

export default bottomLinks;
