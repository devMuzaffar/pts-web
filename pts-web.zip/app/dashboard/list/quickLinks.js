const quickLinksList = [
    {
      icon: "/dashboard/home/chapter.png",
      text: "Chapter Tests",
      desc: "Chapter wise test karday aur mazboot.",
    },
    {
      icon: "/dashboard/home/subject.png",
      text: "Subject Mock Tests",
      desc: "Check karou poray subject ke mazbooti.",
    },
    {
      icon: "/dashboard/home/grand.png",
      text: "Grand Tests",
      desc: "Tayyari ka akri step.",
    },
  ];


export default quickLinksList;