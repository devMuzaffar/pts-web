const inputLabelStyle = { fontSize: 14, lineHeight: "20px", color: "black" };

export default inputLabelStyle;