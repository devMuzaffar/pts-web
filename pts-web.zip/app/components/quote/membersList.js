const membersList = [
    './assets/team/1.avif',
    './assets/team/2.avif',
    './assets/team/3.avif',
]

export default membersList;