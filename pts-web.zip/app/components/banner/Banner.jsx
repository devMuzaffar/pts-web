const Banner = () => {
  return (
    <div className="bg-primary-blue text-gray-100 text-center p-2 hidden sm:block">
        <p className="text-sm">Unlimited Online Course & Video tutorials downloads! Get 30% Off</p>
    </div>
  )
}

export default Banner