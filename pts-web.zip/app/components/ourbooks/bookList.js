const bookList = [
    {img: './assets/books/1.webp', text: "MDCAT"},
    {img: './assets/books/2.webp', text: "PHYSICS PRACTICAL NOTEBOOK INTER"},
    {img: './assets/books/3.webp', text: "CHEMISTRY PRACTICAL NOTEBOOK INTER"},
    {img: './assets/books/4.webp', text: "BIOLOGY PRACTICAL NOTEBOOK INTER"},
];

export default bookList;